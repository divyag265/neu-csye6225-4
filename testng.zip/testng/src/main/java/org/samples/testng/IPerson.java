package org.samples.testng;

public interface IPerson {

	public String getFullName();

}
